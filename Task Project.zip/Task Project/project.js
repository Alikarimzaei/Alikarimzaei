

//////variabels
let addtask = document.getElementById("button");
let input2 = document.getElementById(`count2`)
let cleartask = document.getElementById(`submit2`)
let listitem = document.querySelector(`ul`)
let users = [];
let inputValue = document.getElementById("count");


////////////////////////




addtask.addEventListener("click", myFunction);


////localStorage cods
function myFunction() {
    let userValue = inputValue.value;
    if (userValue == "") {

    } else {
        users.push(userValue);
        localStorage.setItem(`users`, JSON.stringify(users));
        show(JSON.parse(localStorage.getItem(`users`)));

    }
    ///////////////////////


    ////added task code
    function show(users) {

        listitem.innerHTML = ``;
        users.forEach(element => {
            listitem.innerHTML += `<li class="remove p-1 mb-2 bg-primary text-white">
                <i class="fa fa-remove"  style="font-size:24px"></i>
                ${element}</li>`;

            inputValue.value = "";
        });

        ///////////////////////

        //click on the cross and delete task codes
        let deletitem = document.querySelectorAll(`ul li i`);
        deletitem.forEach((coary) => {
            coary.addEventListener(`click`, () => {
                coary.parentNode.remove();
            })
        })


    }


    ///////clear task button cods
    cleartask.addEventListener(`click`, function () {
        listitem.remove();
        localStorage.clear();
    }
    )
    ///////////////////////
}



///////filter input codes

input2.addEventListener(`keyup`, filter);
function filter() {
    let filterlist = (JSON.parse(localStorage.getItem(`users`)));
    let filterxitems = filterlist.filter(function (element) {
        listitem.innerHTML = ``;
        return (element == input2.value);
    })
    filterxitems.forEach((eachitam) => {
        listitem.innerHTML += `<li class="remove p-1 mb-2 bg-primary text-white">
        <i class="fa fa-remove"  style="font-size:24px"></i>
        ${eachitam}</li>`;
    })
}

//////////////////////





